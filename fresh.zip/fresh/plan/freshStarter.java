package fresh.plan;

import fresh.ui.FrmMain;

public class freshStarter {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new FrmMain();
	}

}
