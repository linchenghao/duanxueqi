package fresh.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;


import fresh.itf.Ishangpin_manager;
import fresh.model.BeanFreshinfo;
import fresh.model.BeanFreshkind;
import fresh.model.BeanUserinfo;
import fresh.model.Beanorder;
import fresh.start.UserUtil;
import fresh.util.BaseException;

import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;

public class Frm_shangpin extends JFrame implements ActionListener{
	//private static final BeanFreshinfo BeanFreshinfo = null;
	private BeanFreshkind a=null;
	JButton back = new JButton("\u8FD4\u56DE");
	JButton button = new JButton("\u786E\u8BA4");
	List <BeanFreshkind> allkind = null;
	List <BeanFreshinfo> allshangpin = null;
	 private Object tblshangpinData[][];
	 DefaultTableModel tabshangpinModel=new DefaultTableModel();
	 private Object tblshangpinTitle[]=BeanFreshinfo.tblshangpinTitle;
	 private JTable datashangpinPlan=new JTable(tabshangpinModel);
	 private JLabel label;
	 private JTextField countField;
	 
	 private Object tblkindData[][];
	 DefaultTableModel tabkindModel=new DefaultTableModel();
	 private Object tblkindTitle[]=BeanFreshkind.tblkindTitle;
	 private JTable datakindPlan=new JTable(tabkindModel);
	 private JTable table;
	 private  void reloadkindTable() {
		  try {
		   allkind = UserUtil.kind_manager.loadall();
		  }catch (BaseException e) {
		   JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
		   return;
		  }
		  tblkindData =  new Object[allkind.size()][BeanFreshkind.tblkindTitle.length];
		  for(int i=0;i<allkind.size();i++){
			  for(int j=0;j<BeanFreshkind.tblkindTitle.length;j++)
				  tblkindData[i][j]=allkind.get(i).getCell(j);
		  }
		  tabkindModel.setDataVector(tblkindData,tblkindTitle);
		  this.datakindPlan.validate();
		  this.datakindPlan.repaint();
		 }
	 private void reloadfreshinfoTable(int planIdx){
			if(planIdx<0) return;
			a = allkind.get(planIdx);
			try {
				allshangpin=UserUtil.shangpin_manager.loadall(a);
			} catch (BaseException e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			tblshangpinData =new Object[allshangpin.size()][BeanFreshinfo.tblshangpinTitle.length];
			for(int i=0;i<allshangpin.size();i++){
				for(int j=0;j<BeanFreshinfo.tblshangpinTitle.length;j++)
					tblshangpinData[i][j]=allshangpin.get(i).getCell(j);
			}
			
			tabshangpinModel.setDataVector(tblshangpinData,tblshangpinTitle);
			this.datashangpinPlan.validate();
			this.datashangpinPlan.repaint();
		}
	 BeanFreshinfo p= null;
	 
	public Frm_shangpin(Frame f,String s,boolean b) {
		setVisible(true);
		this.setTitle("������Ϣ");
		getContentPane().setLayout(null);
		JScrollPane scrollPane_1 = new JScrollPane(this.datakindPlan);
		scrollPane_1.setBounds(0, 0, 0, 0);
		this.getContentPane().add(scrollPane_1);
		
		this.datakindPlan.addMouseListener(new MouseAdapter () {
			public void mouseClicked(MouseEvent e) {
				int i=Frm_shangpin.this.datakindPlan.getSelectedRow();
				if(i<0) {
					return;
				}
				Frm_shangpin.this.reloadfreshinfoTable(i);
			}
		});
		
		this.datashangpinPlan.addMouseListener(new MouseAdapter () {
			public void mouseClicked(MouseEvent e) {
				int i=Frm_shangpin.this.datashangpinPlan.getSelectedRow();
				if(i<0) {
					return;
				}
				p = allshangpin.get(i);
			}
		});
		     button.setBounds(703, 379, 0, 0);
		     button.setBounds(539, 373, 109, 32);
		     
		     
		     button.addActionListener(new ActionListener() {
		     	public void actionPerformed(ActionEvent e) {
		     	}
		     });
		     
		     JLabel count = new JLabel("\u6570\u91CF");
		     count.setBounds(372, 370, 48, 38);
		     
		     table = new JTable();
		     table.setBounds(610, 63, 1, 1);
		     getContentPane().add(table);
		     getContentPane().add(count);
		     getContentPane().add(button);
		     
		     countField = new JTextField();
		     countField.setBounds(450, 379, 66, 21);
		     getContentPane().add(countField);
		     countField.setColumns(10);
		     JScrollPane scrollPane = new JScrollPane(this.datakindPlan);
		     scrollPane.setBounds(0, 0, 393, 309);
		       this.getContentPane().add(scrollPane);
			   JScrollPane scrollPane1 = new JScrollPane(this.datashangpinPlan);
			    scrollPane1.setBounds(393, 0, 594, 309);
			     this.getContentPane().add(scrollPane1);
			       
			 
			       back.setBounds(868, 378, 97, 23);
			       getContentPane().add(back);
			       this.reloadkindTable();	       
		this.setSize(1011,500);
		button.addActionListener(this);
		back.addActionListener(this);
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == this.button) {
			String b=this.countField.getText();
			if (p==null) {
				JOptionPane.showMessageDialog(null,"δѡ����Ʒ", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			//System.out.print(p.getCount()+"111");
			 try {
				UserUtil.userordermanager.xiadan(p,Integer.valueOf(b));
			} catch (NumberFormatException | BaseException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}

			new Frmchooseadd();
			this.setVisible(false);
			
		} 
		else if(e.getSource() == this.back) {
			this.setVisible(false);
		}
	}
}


