package fresh.itf;

import java.util.List;

import fresh.model.BeanFreshinfo;
import fresh.model.BeanFreshkind;
import fresh.model.BeanUserinfo;
import fresh.model.Beanadmin;
import fresh.model.Beanadmininfo;
import fresh.start.UserUtil;
import fresh.util.BaseException;
import fresh.util.BusinessException;
import fresh.util.DbException;

public interface Iadminmanager {

	Beanadmin login(String admin, String pwd) throws BusinessException, DbException;

	List<Beanadmininfo> loadall() throws  BaseException;
	BeanFreshinfo add(String kind_id,String shangpin_id,String shangpin_name,String price,String vipp,String count,String guige,String specific)throws BaseException;
	BeanFreshinfo del(String shangpin_id)throws BaseException;
	BeanFreshkind addkind(String kind_id, String kind_name, String kind_discribe) throws BaseException;
}
