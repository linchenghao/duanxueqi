package fresh.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JPasswordField;
import com.mysql.jdbc.Util;

import fresh.model.Beanadmin;
import fresh.start.UserUtil;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.SwingConstants;

public class Frmadminlogin extends JFrame implements ActionListener{

	private JPanel contentPane;
	private JTextField admin = new JTextField();
	private JLabel label;
	private JLabel label_1;
	private JButton button;
	private JPasswordField passwd;
	private JButton back;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public Frmadminlogin() {
		setVisible(true);
		setTitle("\u7BA1\u7406\u5458\u767B\u5F55");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u7BA1\u7406\u5458\u7528\u6237\u540D");
		label.setBounds(56, 70, 102, 15);
		contentPane.add(label);
		
		label_1 = new JLabel("\u5BC6\u7801");
		label_1.setBounds(100, 138, 58, 15);
		contentPane.add(label_1);
		
		admin = new JTextField();
		admin.setBounds(138, 67, 143, 21);
		contentPane.add(admin);
		admin.setColumns(10);
		
		button = new JButton("\u767B\u5F55");
		button.setBounds(56, 197, 97, 23);
		contentPane.add(button);
		
		passwd = new JPasswordField();
		passwd.setBounds(138, 135, 143, 21);
		contentPane.add(passwd);
		
		back = new JButton("\u8FD4\u56DE");
		back.setBounds(200, 197, 102, 23);
		contentPane.add(back);
		this.button.addActionListener(this);
		this.back.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == this.button) {
			String Admin = this.admin.getText();
			String pwd=new String(this.passwd.getPassword());
			try {
				Beanadmin.currentLoginUser = UserUtil.adminmanager.login(Admin,pwd);
			} catch(Exception e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			new Frmadmin();
			this.setVisible(false);
		}
		else if(e.getSource() == this.back) {
			this.setVisible(false);
		}
	}

}