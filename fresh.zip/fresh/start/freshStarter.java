package fresh.start;

import fresh.ui.FrmLogin;
import fresh.ui.FrmMain;

public class freshStarter {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new FrmLogin();
	}

}
