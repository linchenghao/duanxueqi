package fresh.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import fresh.model.Beanorder;
import fresh.start.UserUtil;
import fresh.util.BaseException;


import javax.swing.JTable;
import javax.swing.JButton;

public class FrmUserorder extends JFrame implements ActionListener{
	JButton back = new JButton("\u8FD4\u56DE");
	private JPanel contentPane;
	List <Beanorder> allorder = null;
	 private Object tblorderData[][];
	 DefaultTableModel taborderModel=new DefaultTableModel();
	 private Object tblorderTitle[]=Beanorder.tblorderTitle;
	 private JTable dataorderPlan=new JTable(taborderModel);
	 private  void reloadorderTable() {
		  try {
		   allorder = UserUtil.userordermanager.loadall();
		  }catch (BaseException e) {
		   JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
		   return;
		  }
		  tblorderData =  new Object[allorder.size()][Beanorder.tblorderTitle.length];
		  //System.out.print(allshangpin.size());
		  for(int i=0;i<allorder.size();i++){
			  for(int j=0;j<Beanorder.tblorderTitle.length;j++)
				  tblorderData[i][j]=allorder.get(i).getCell(j);
		  }
		  taborderModel.setDataVector(tblorderData,tblorderTitle);
		  this.dataorderPlan.validate();
		  this.dataorderPlan.repaint();
		  back.addActionListener(this);
		 }
	/**
	 * Launch the application.
	 */


	/**
	 * Create the frame.
	 */
	public FrmUserorder() {
		setVisible(true);
		this.setTitle("������Ϣ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 570, 339);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
	
		JScrollPane scrollPane1 = new JScrollPane(this.dataorderPlan);
		scrollPane1.setBounds(10, 10, 536, 248);
	       contentPane.setLayout(null);
	       this.getContentPane().add(scrollPane1);
	       
	       
	       back.setBounds(449, 269, 97, 23);
	       contentPane.add(back);
	       this.reloadorderTable();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == this.back) {
			this.setVisible(false);
		}
	}

}
