package fresh.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import fresh.model.BeanUserinfo;
import fresh.util.BaseException;
import fresh.start.UserUtil;

import java.awt.Font;


public class FrmUserlogin extends JFrame implements ActionListener {
	private JButton Login = new JButton("\u767B\u5F55");
	private JButton Exit = new JButton("�˳�");
	
	private JLabel lblUser = new JLabel("\u7528\u6237\u540D\uFF1A");
	private JLabel lblPwd = new JLabel("���룺");
	private JTextField UserId = new JTextField(20);
	private JPasswordField Pwd = new JPasswordField(20);

	public FrmUserlogin() {
		setFont(new Font("Dialog", Font.PLAIN, 12));
		
		setVisible(true);
		setTitle("\u7528\u6237\u767B\u5F55");
		Exit.setBounds(171, 153, 65, 23);
		Exit.addActionListener(this);
				Login.setBounds(79, 153, 74, 23);
		
				Login.addActionListener(this);
		getContentPane().setLayout(null);
		lblPwd.setBounds(21, 98, 65, 15);
		getContentPane().add(lblPwd);
		lblUser.setBounds(21, 33, 65, 15);
		getContentPane().add(lblUser);
		Pwd.setBounds(96, 95, 126, 21);
		getContentPane().add(Pwd);
		UserId.setBounds(96, 30, 126, 21);
		getContentPane().add(UserId);
		getContentPane().add(Login);
		getContentPane().add(Exit);
		this.setSize(368, 223);
		// ��Ļ������ʾ
		double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((int) (width - this.getWidth()) / 2,
				(int) (height - this.getHeight()) / 2);

		this.validate();
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == this.Login) {
			String userid=this.UserId.getText();
			String pwd=new String(this.Pwd.getPassword());
			try {
				BeanUserinfo.currentLoginUser= UserUtil.usermanager.login(userid, pwd);
			} catch (Exception e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			new FrmUser();
			this.setVisible(false);
			
		} else if (e.getSource() == this.Exit) {
			System.exit(0);
			} 

	}
}