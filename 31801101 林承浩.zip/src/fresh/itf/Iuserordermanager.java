package fresh.itf;

import java.util.List;

import fresh.model.BeanFreshinfo;
import fresh.model.BeanFreshkind;
import fresh.model.BeanUserinfo;
import fresh.model.Beanaddress;
import fresh.model.Beanorder;
import fresh.util.BaseException;

public interface Iuserordermanager {
	public List<Beanorder> loadall() throws  BaseException;
	public Beanorder xiadan(BeanFreshinfo i,int b)throws BaseException;
	public Beanorder choose(Beanaddress p)throws BaseException;
}
