package fresh.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import fresh.model.BeanFreshinfo;
import fresh.start.UserUtil;
import fresh.util.BaseException;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

public class Frmdelshangpin extends JFrame implements ActionListener{

	private JPanel contentPane;
	private JTextField textField;
	JButton button = new JButton("\u786E\u5B9A\u5220\u9664");
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Frmdelshangpin frame = new Frmdelshangpin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Frmdelshangpin() {
		this.setVisible(true);
		setTitle("\u5220\u9664\u751F\u9C9C");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u5220\u9664\u5546\u54C1\u7F16\u53F7");
		label.setBounds(26, 26, 122, 15);
		contentPane.add(label);
		
		textField = new JTextField();
		textField.setBounds(201, 23, 66, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		
		button.setBounds(26, 80, 97, 23);
		contentPane.add(button);
		button.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == this.button) {
			String shangpinid = this.textField.getText();
		    try {
				BeanFreshinfo.currentLoginUser=UserUtil.adminmanager.del(shangpinid);
		    	 
		    }catch (BaseException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
				return;
				}
		    this.setVisible(false);
		}
	}

}
