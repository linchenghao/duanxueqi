package fresh.model;	
//	public static Object[] tblshangpinTitle;
	public class BeanFreshinfo {
		private String kind_id;
		private String shangpin_id;
		private String shangpin_name;
		private double price;
		private double huiyuan_price;
		private int count;
		private String guige;
		private String specific;
		public static BeanFreshinfo currentLoginUser=null;
		public static final String[] tblshangpinTitle={"������","��Ʒ���","��Ʒ����","�۸�","��Ա��","����","���","����"};
		public String getCell(int col){
		  if(col==0) return this.getKind_id();
		  else if(col==1) return this.getShangpin_id();
		  else if(col==2) return ""+this.getShangpin_name();
		  else if(col==3) return ""+this.getPrice();
		  else if(col==4) return ""+this.getHuiyuan_price();
		  else if(col==5) return ""+this.getCount();
		  else if(col==6) return ""+this.getGuige();
		  else if(col==7) return ""+this.getSpecific();
		  else return "";
		 }
		public String getKind_id() {
			return kind_id;
		}

		public void setKind_id(String kind_id) {
			this.kind_id = kind_id;
		}
		public String getShangpin_id() {
			return shangpin_id;
		}

		public void setShangpin_id(String shangpin_id) {
			this.shangpin_id = shangpin_id;
		}

		public String getShangpin_name() {
			return shangpin_name;
		}

		public void setShangpin_name(String shangpin_name) {
			this.shangpin_name = shangpin_name;
		}

		public double getPrice() {
			return price;
		}

		public void setPrice(double price) {
			this.price = price;
		}

		public double getHuiyuan_price() {
			return huiyuan_price;
		}

		public void setHuiyuan_price(double huiyuan_price) {
			this.huiyuan_price = huiyuan_price;
		}

		public int getCount() {
			return count;
		}

		public void setCount(int count) {
			this.count = count;
		}

		public String getGuige() {
			return guige;
		}

		public void setGuige(String guige) {
			this.guige = guige;
		}

		public String getSpecific() {
			return specific;
		}

		public void setSpecific(String specific) {
			this.specific = specific;
		}
		
}

	
