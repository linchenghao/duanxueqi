package fresh.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import fresh.model.BeanUserinfo;
import fresh.start.UserUtil;
import fresh.util.BaseException;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

public class FrmUserReg extends JFrame implements ActionListener{

	private JPanel contentPane;
	private JTextField textField = new JTextField(20);
	private JTextField userid;
	private JPasswordField passwordField = new JPasswordField(20);
	private JPasswordField passwordField_1 = new JPasswordField(20);

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	JButton button = new JButton("\u6CE8\u518C");
	private JTextField username;
	private JTextField userphone;
	private JTextField usercity;
	private JTextField useremail;
	private JTextField uservip;
	private JTextField usersex;
	public FrmUserReg() {
		setVisible(true);
		setTitle("\u7528\u6237\u6CE8\u518C");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 534);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u7528\u6237\u540D");
		label.setBounds(86, 35, 58, 15);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u5BC6\u7801");
		label_1.setBounds(86, 84, 58, 18);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("\u786E\u8BA4\u5BC6\u7801");
		label_2.setBounds(86, 131, 58, 15);
		contentPane.add(label_2);
		
		userid = new JTextField();
		userid.setBounds(180, 32, 141, 21);
		contentPane.add(userid);
		userid.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(180, 81, 141, 21);
		contentPane.add(passwordField);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(180, 128, 141, 21);
		contentPane.add(passwordField_1);
		
		
		button.setBounds(180, 449, 141, 23);
		contentPane.add(button);
		
		username = new JTextField();
		username.setBounds(180, 171, 141, 21);
		contentPane.add(username);
		username.setColumns(10);
		
		userphone = new JTextField();
		userphone.setColumns(10);
		userphone.setBounds(180, 258, 141, 21);
		contentPane.add(userphone);
		
		usercity = new JTextField();
		usercity.setColumns(10);
		usercity.setBounds(180, 300, 141, 21);
		contentPane.add(usercity);
		
		JLabel label_3 = new JLabel("\u59D3\u540D");
		label_3.setBounds(86, 174, 58, 15);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("\u624B\u673A\u53F7");
		label_4.setBounds(86, 261, 58, 15);
		contentPane.add(label_4);
		
		JLabel label_5 = new JLabel("\u6240\u5728\u57CE\u5E02\r\n");
		label_5.setBounds(86, 303, 58, 15);
		contentPane.add(label_5);
		
		JLabel label_6 = new JLabel("\u90AE\u7BB1");
		label_6.setBounds(86, 348, 58, 15);
		contentPane.add(label_6);
		
		useremail = new JTextField();
		useremail.setColumns(10);
		useremail.setBounds(180, 345, 141, 21);
		contentPane.add(useremail);
		
		JLabel label_7 = new JLabel("\u662F\u5426\u4F1A\u5458");
		label_7.setBounds(86, 393, 58, 15);
		contentPane.add(label_7);
		
		uservip = new JTextField();
		uservip.setColumns(10);
		uservip.setBounds(180, 390, 141, 21);
		contentPane.add(uservip);
		
		usersex = new JTextField();
		usersex.setColumns(10);
		usersex.setBounds(180, 217, 141, 21);
		contentPane.add(usersex);
		
		JLabel label_8 = new JLabel("\u6027\u522B");
		label_8.setBounds(86, 220, 58, 15);
		contentPane.add(label_8);
		this.button.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == this.button)
		{
			String userid = this.userid.getText();
		    String pwd = new String(this.passwordField.getPassword());
		    String pwd2 = new String(this.passwordField_1.getPassword());
		    String name = this.username.getText();
		    String sex = this.usersex.getText();
		    String phone = this.userphone.getText();
		    String email = this.useremail.getText();
		    String city = this.usercity.getText();
		    String huiyuan = this.uservip.getText();
		    try {
		    	BeanUserinfo.currentLoginUser=UserUtil.usermanager.reg(userid, pwd, pwd2, name, sex, phone, email, city, huiyuan);
		    	 
		    }catch (BaseException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
				return;
				}
		    this.setVisible(false);
		}
	}
}
