package fresh.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import fresh.model.BeanUserinfo;
import fresh.model.Beanaddress;
import fresh.model.Beanadmininfo;
import fresh.start.UserUtil;
import fresh.util.BaseException;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FrmUseradd extends JFrame implements ActionListener{
	JButton back = new JButton("\u8FD4\u56DE");
	private JPanel contentPane;
	List <Beanaddress> aaa = null;
	 private Object tbluseraddData[][];
	 DefaultTableModel tabuseraddModel=new DefaultTableModel();
	 private Object tbluseraddTitle[]=Beanaddress.tbluseraddTitle;
	 private JTable datauseraddPlan=new JTable(tabuseraddModel);
	 private  void reloaduseraddTable() {
		  try {
		   aaa = UserUtil.usermanager.loadall(BeanUserinfo.currentLoginUser);
		  }catch (BaseException e) {
		   JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
		   return;
		  }
		  tbluseraddData =  new Object[aaa.size()][Beanaddress.tbluseraddTitle.length];
		  //System.out.print(allshangpin.size());
		  for(int i=0;i<aaa.size();i++){
			  for(int j=0;j<Beanaddress.tbluseraddTitle.length;j++)
				  tbluseraddData[i][j]=aaa.get(i).getCell(j);
		  }
		  tabuseraddModel.setDataVector(tbluseraddData,tbluseraddTitle);
		  this.datauseraddPlan.validate();
		  this.datauseraddPlan.repaint();
		 }
	/**
	 * Launch the application.
	 */


	/**
	 * Create the frame.
	 */
	public FrmUseradd() {
		setVisible(true);
		this.setTitle("�û���ַ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 725, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
	
		JScrollPane scrollPane1 = new JScrollPane(this.datauseraddPlan);
		scrollPane1.setBounds(5, 5, 596, 258);
	       contentPane.setLayout(null);
	       this.getContentPane().add(scrollPane1);
	       
	    
	       back.addActionListener(new ActionListener() {
	       	public void actionPerformed(ActionEvent e) {
	       	}
	       });
	       back.setBounds(617, 199, 94, 23);
	       contentPane.add(back);
	       this.reloaduseraddTable();
	       back.addActionListener(this);
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		    if(e.getSource() == this.back) {
			this.setVisible(false);
		}
	}

}
