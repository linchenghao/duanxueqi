package fresh.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import fresh.model.BeanUserinfo;
import fresh.model.Beanaddress;
import fresh.start.UserUtil;
import fresh.util.BaseException;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class Frmaddress extends JFrame implements ActionListener{
	public BeanUserinfo userid;
	private JPanel contentPane;
	private JTextField textaddid;
	private JTextField textsheng;
	private JTextField textshi;
	private JTextField textqu;
	private JTextField textaddress;
	private JTextField textusername;
	private JTextField textuserphone;
	private JButton button;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public Frmaddress() {
		setVisible(true);
		
		setTitle("\u5730\u5740\u4FE1\u606F");
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel addid = new JLabel("\u5730\u5740\u7F16\u53F7");
		addid.setBounds(15, 48, 64, 16);
		addid.setFont(new Font("����", Font.PLAIN, 14));
		
		JLabel sheng = new JLabel("\u7701");
		sheng.setBounds(15, 78, 64, 16);
		sheng.setFont(new Font("����", Font.PLAIN, 14));
		
		JLabel shi = new JLabel("\u5E02");
		shi.setBounds(15, 108, 58, 16);
		shi.setFont(new Font("����", Font.PLAIN, 14));
		
		JLabel qu = new JLabel("\u533A");
		qu.setBounds(15, 135, 48, 16);
		qu.setFont(new Font("����", Font.PLAIN, 14));
		
		JLabel address = new JLabel("\u8BE6\u7EC6\u5730\u5740");
		address.setBounds(15, 161, 64, 16);
		address.setFont(new Font("����", Font.PLAIN, 14));
		
		JLabel username = new JLabel("\u7528\u6237\u59D3\u540D");
		username.setBounds(15, 196, 64, 16);
		username.setFont(new Font("����", Font.PLAIN, 14));
		
		JLabel userphone = new JLabel("\u7528\u6237\u624B\u673A\u53F7");
		userphone.setBounds(5, 231, 74, 16);
		userphone.setFont(new Font("����", Font.PLAIN, 14));
		
		textaddid = new JTextField();
		textaddid.setBounds(97, 48, 114, 17);
		textaddid.setColumns(10);
		
		textsheng = new JTextField();
		textsheng.setBounds(97, 78, 114, 17);
		textsheng.setColumns(10);
		
		textshi = new JTextField();
		textshi.setBounds(97, 108, 114, 17);
		textshi.setColumns(10);
		
		textqu = new JTextField();
		textqu.setBounds(97, 135, 114, 17);
		textqu.setColumns(10);
		
		textaddress = new JTextField();
		textaddress.setBounds(97, 161, 114, 17);
		textaddress.setColumns(10);
		
		textusername = new JTextField();
		textusername.setBounds(97, 196, 114, 17);
		textusername.setColumns(10);
		
		textuserphone = new JTextField();
		textuserphone.setBounds(97, 231, 114, 17);
		textuserphone.setColumns(10);
		
		button = new JButton("\u786E\u5B9A");
		button.setBounds(276, 75, 97, 23);
		contentPane.setLayout(null);
		contentPane.add(userphone);
		contentPane.add(textuserphone);
		contentPane.add(qu);
		contentPane.add(shi);
		contentPane.add(sheng);
		contentPane.add(address);
		contentPane.add(username);
		contentPane.add(textusername);
		contentPane.add(textsheng);
		contentPane.add(button);
		contentPane.add(textshi);
		contentPane.add(textaddress);
		contentPane.add(textqu);
		contentPane.add(addid);
		contentPane.add(textaddid);
		this.button.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == this.button) {
			String addid = this.textaddid.getText();
			String sheng = this.textsheng.getText();
			String shi = this.textshi.getText();
			String qu = this.textqu.getText();
			String address= this.textaddress.getText();
			String username = this.textusername.getText();
			String userphone = this.textuserphone.getText();
			System.out.println(BeanUserinfo.currentLoginUser.getuser_id());
		    try { 
				Beanaddress.currentLoginUser=UserUtil.usermanager.add(addid, BeanUserinfo.currentLoginUser.getuser_id(), sheng, shi, qu, address, username, userphone);
		     
		    }catch (BaseException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
				return;
				}
		    this.setVisible(false);
		}
	}
}
