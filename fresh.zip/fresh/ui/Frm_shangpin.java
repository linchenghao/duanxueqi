package fresh.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;


import fresh.itf.Ishangpin_manager;
import fresh.model.BeanFreshinfo;
import fresh.model.BeanFreshkind;
import fresh.start.UserUtil;
import fresh.util.BaseException;

import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;

public class Frm_shangpin extends JFrame implements ActionListener{
	//private static final BeanFreshinfo BeanFreshinfo = null;
	private BeanFreshkind a=null;
	JButton button = new JButton("\u786E\u8BA4");
	List <BeanFreshkind> allkind = null;
	List <BeanFreshinfo> allshangpin = null;
	 private Object tblshangpinData[][];
	 DefaultTableModel tabshangpinModel=new DefaultTableModel();
	 private Object tblshangpinTitle[]=BeanFreshinfo.tblshangpinTitle;
	 private JTable datashangpinPlan=new JTable(tabshangpinModel);
	 private JLabel label;
	 private JTextField countField;
	 
	 private Object tblkindData[][];
	 DefaultTableModel tabkindModel=new DefaultTableModel();
	 private Object tblkindTitle[]=BeanFreshkind.tblkindTitle;
	 private JTable datakindPlan=new JTable(tabkindModel);
	 private JTable table;
	 private  void reloadkindTable() {
		  try {
		   allkind = UserUtil.kind_manager.loadall();
		  }catch (BaseException e) {
		   JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
		   return;
		  }
		  tblkindData =  new Object[allkind.size()][BeanFreshkind.tblkindTitle.length];
		  //System.out.print(allshangpin.size());
		  for(int i=0;i<allkind.size();i++){
			  for(int j=0;j<BeanFreshkind.tblkindTitle.length;j++)
				  tblkindData[i][j]=allkind.get(i).getCell(j);
		  }
		  tabkindModel.setDataVector(tblkindData,tblkindTitle);
		  this.datakindPlan.validate();
		  this.datakindPlan.repaint();
		 }
	 private void reloadfreshinfoTable(int planIdx){
			if(planIdx<0) return;
			a = allkind.get(planIdx);
			try {
				allshangpin=UserUtil.shangpin_manager.loadall(a);
			} catch (BaseException e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			tblshangpinData =new Object[allshangpin.size()][BeanFreshinfo.tblshangpinTitle.length];
			for(int i=0;i<allshangpin.size();i++){
				for(int j=0;j<BeanFreshinfo.tblshangpinTitle.length;j++)
					tblshangpinData[i][j]=allshangpin.get(i).getCell(j);
			}
			
			tabshangpinModel.setDataVector(tblshangpinData,tblshangpinTitle);
			this.datashangpinPlan.validate();
			this.datashangpinPlan.repaint();
		}
	public Frm_shangpin(Frame f,String s,boolean b) {
//		Frame f,String s,boolean b
		//super(f,s,b);
		setVisible(true);
		this.setTitle("������Ϣ");
		getContentPane().setLayout(null);
		JScrollPane scrollPane_1 = new JScrollPane(this.datakindPlan);
		scrollPane_1.setBounds(0, 0, 0, 0);
		this.getContentPane().add(scrollPane_1);
		this.datakindPlan.addMouseListener(new MouseAdapter () {
			public void mouseClicked(MouseEvent e) {
				int i=Frm_shangpin.this.datakindPlan.getSelectedRow();
				if(i<0) {
					return;
				}
				Frm_shangpin.this.reloadfreshinfoTable(i);
			}
		});
		     button.setBounds(0, 0, 0, 0);
		//this.getContentPane().add(new JScrollPane(this.datashangpinPlan), BorderLayout.CENTER);
		//this.reloadkindTable();
		//		  JScrollPane scrollPane = new JScrollPane(this.datashangpinPlan);
//		  scrollPane.setBounds(0, 0, 524, 357);
//		     button.setBounds(539, 373, 109, 32);
		     
		     
		     button.addActionListener(new ActionListener() {
		     	public void actionPerformed(ActionEvent e) {
		     	}
		     });
		     
		     JLabel count = new JLabel("\u6570\u91CF");
		     count.setBounds(370, 367, 48, 38);
//		     getContentPane().add(scrollPane);
		     
		     table = new JTable();
		     table.setBounds(610, 63, 1, 1);
		     getContentPane().add(table);
		     getContentPane().add(count);
		     getContentPane().add(button);
		     
		     countField = new JTextField();
		     countField.setBounds(441, 376, 66, 21);
		     getContentPane().add(countField);
		     countField.setColumns(10);
		     JScrollPane scrollPane = new JScrollPane(this.datakindPlan);
		     scrollPane.setBounds(53, 124, 629, 192);
		       this.getContentPane().add(scrollPane);
			     JScrollPane scrollPane1 = new JScrollPane(this.datashangpinPlan);
			     scrollPane1.setBounds(23, 10, 324, 97);
			       this.getContentPane().add(scrollPane1);
		/*table = new JTable();
		table.setBounds(241, 10, 1, 1);
		getContentPane().add(table);*/
			       this.reloadkindTable();
			       //this.reloadfreshinfoTable(planIdx);
		this.setSize(724,500);
	}


	@Override
	public void actionPerformed(ActionEvent e) {
//	 TODO Auto-generated method stub
		if(e.getSource() == this.button) {
			
		}

	}
}


//private  void reloadshangpinTable() {
//try {
// allshangpin = UserUtil.shangpin_manager.loadall();
//}catch (BaseException e) {
// JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
// return;
//}
//tblshangpinData =  new Object[allshangpin.size()][BeanFreshinfo.tblshangpinTitle.length];
////System.out.print(allshangpin.size());
//for(int i=0;i<allshangpin.size();i++){
//	  for(int j=0;j<BeanFreshinfo.tblshangpinTitle.length;j++)
//		  tblshangpinData[i][j]=allshangpin.get(i).getCell(j);
//}
//tabshangpinModel.setDataVector(tblshangpinData,tblshangpinTitle);
//this.datashangpinPlan.validate();
//this.datashangpinPlan.repaint();
//}


