package fresh.start;
import fresh.control.kind_manager;
import fresh.control.usermanager;
import fresh.itf.Ikind_manager;
import fresh.itf.Ishangpin_manager;
import fresh.itf.Iusermanager;


public class UserUtil {

	public static Iusermanager usermanager=new usermanager();
	public static Ishangpin_manager shangpin_manager= new fresh.control.shangpin_manager();
	public static Ikind_manager kind_manager = new kind_manager();
}
