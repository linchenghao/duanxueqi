package fresh.control;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import fresh.itf.Iusermanager;
import fresh.model.BeanFreshinfo;
import fresh.model.BeanFreshkind;
import fresh.model.BeanUserinfo;
import fresh.model.Beanaddress;
import fresh.util.BaseException;
import fresh.util.BusinessException;
import fresh.util.DBUtil;
import fresh.util.DbException;

public class usermanager implements Iusermanager {
	@Override
    public BeanUserinfo login(String user_id,String pwd) throws BusinessException, DbException
    {
    	Connection conn=null;
	    try {
	    	conn=DBUtil.getConnection();
	    	String sql = "select * from tbl_user where user_id = ? ";
	    	java.sql.PreparedStatement pst=conn.prepareStatement(sql);
	    	pst.setString(1,user_id);
	    	java.sql.ResultSet rs=pst.executeQuery();
			if(!rs.next()) throw new BusinessException("��¼�˺Ų�����");
			BeanUserinfo a=new BeanUserinfo();
			a.setuser_id(rs.getString(1));
			a.setuser_name(rs.getString(2));
			a.setuser_sex(rs.getString(3));
			a.setuser_pwd(rs.getString(4));
			a.setuser_phone(rs.getString(5));
			a.setuser_email(rs.getString(6));
			a.setuser_city(rs.getString(7));
			if(!pwd.equals(a.getuser_pwd()))
				throw new BusinessException("�������");
			pst.close();
			rs.close();
			return a;
	    }catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		// TODO Auto-generated method stub
	    
	}

	@Override
	public BeanUserinfo reg(String user_id, String user_pwd, String pwd2, String user_name, String user_sex, String user_phone, String user_city,String user_email,  String user_huiyuan) throws BaseException {
		if(user_id.equals(""))
			throw new BusinessException("�û�������Ϊ��");
		if(user_pwd.equals("")||pwd2.equals(""))
			throw new BusinessException("���벻��Ϊ��");
		if(!user_pwd.equals(pwd2))
				throw new BusinessException("������һ�µ�����");
		if(user_name.equals(""))
			throw new BusinessException("��������Ϊ��");
		if(user_sex.equals(""))
			throw new BusinessException("�Ա���Ϊ��");
		if(user_phone.equals(""))
			throw new BusinessException("�ֻ��Ų���Ϊ��");
		if(user_city.equals(""))
			throw new BusinessException("���ڳ��в���Ϊ��");
		if(user_email.equals(""))
			throw new BusinessException("���䲻��Ϊ��");
		if(user_huiyuan.equals(""))
			throw new BusinessException("�Ƿ��Ա����Ϊ��");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from tbl_user where user_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,user_id);
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) throw new BusinessException("�û����ظ�");
			sql = "insert into tbl_user(user_id,user_name,user_sex,user_pwd,user_phone,user_email,user_city,register_time,user_huiyuan,end_time) values(?,?,?,?,?,?,?,?,?,?)";
		    pst=conn.prepareStatement(sql);
		    pst.setString(1, user_id);
			pst.setString(2,user_name);
			pst.setString(3,user_sex);
			pst.setString(4, user_pwd);
			pst.setString(5, user_phone);
			pst.setString(6, user_email);
			pst.setString(7, user_city);
			pst.setTimestamp(8, new java.sql.Timestamp(System.currentTimeMillis()));
			pst.setString(9, user_huiyuan);
			pst.setTimestamp(10,new java.sql.Timestamp(System.currentTimeMillis() + 3600000000L));
			pst.execute();
			pst.close();
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		// TODO Auto-generated method stub
		return null;
	}
	public void changePwd(String oldPwd,String newPwd, String newPwd2) throws BaseException{
		if(oldPwd==null||"".equals(oldPwd)) throw new BusinessException("��ʼ���벻��Ϊ��");
		if(newPwd==null||"".equals(newPwd)) throw new BusinessException("�����벻��Ϊ��");
		if(!(newPwd2.equals(newPwd))) throw new BusinessException("�������벻һ��");
		Connection conn=null;
	    try {
	    	conn=DBUtil.getConnection();
	    	String sql = "select * from tbl_user where user_id = ? ";
	    	
	    	java.sql.PreparedStatement pst=conn.prepareStatement(sql);
	    	pst.setString(1,BeanUserinfo.currentLoginUser.getuser_id());
	    	java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				if(!(oldPwd.equals(BeanUserinfo.currentLoginUser.getuser_pwd()))) throw new BusinessException("��ʼ�����������");
				sql="update tbl_user set user_pwd=? where user_id =?";
				pst=conn.prepareStatement(sql);		
				pst.setString(1, newPwd);
				pst.setString(2, BeanUserinfo.currentLoginUser.getuser_id());
				pst.execute();
			}
			pst.close();
			rs.close();
			
	    }catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		// TODO Auto-generated method stub
	}
	public Beanaddress add(String add_id, String user, String add_sheng, String add_shi, String add_qu, String address, String user_name, String user_phone) throws BaseException{
		if(add_id.equals(""))
			throw new BusinessException("��ַ��Ų���Ϊ��");
		if(add_sheng.equals(""))
			throw new BusinessException("ʡ����Ϊ��");
		if(add_shi.equals(""))
			throw new BusinessException("�в���Ϊ��");
		if(add_qu.equals(""))
			throw new BusinessException("������Ϊ��");
		if(address.equals(""))
			throw new BusinessException("��ϸ��ַ����Ϊ��");
		if(user_name.equals(""))
			throw new BusinessException("�û���������Ϊ��");
		if(user_phone.equals(""))
			throw new BusinessException("�û��ֻ��Ų���Ϊ��");
		Connection conn=null;
		try {
			String userid = user;
			conn=DBUtil.getConnection();
			String sql="select * from tbl_user_add";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			sql = "insert into tbl_user_add(add_id, user_id, add_sheng, add_shi, add_qu, address, user_name, user_phone) values(?,?,?,?,?,?,?,?)";
		    pst=conn.prepareStatement(sql);
		    pst.setString(1, add_id);
			pst.setString(2, userid);
			pst.setString(3, add_sheng);
			pst.setString(4, add_shi);
			pst.setString(5, add_qu);
			pst.setString(6, address);
			pst.setString(7,user_name);
			pst.setString(8,user_phone);
			pst.execute();
			pst.close();
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return null;
	}
	//��ַ
	public List<Beanaddress> loadall(BeanUserinfo a) throws BaseException {
		// TODO Auto-generated method stub
		List<Beanaddress> resultBeanFreshinfos = new ArrayList<Beanaddress>();
    	Connection conn=null;
	    try {
	    	
	    	conn=DBUtil.getConnection();
	    	String sql = "select * from tbl_user_add where user_id = ?";
	    
	    	java.sql.PreparedStatement pst=conn.prepareStatement(sql);
	    	pst.setString(1, a.getuser_id());
	    	java.sql.ResultSet rs=pst.executeQuery();
	    	
	    	while(rs.next())
	    	{
	    		Beanaddress b=new Beanaddress();
				b.setadd_id(rs.getString(1));
				b.setuser_id(rs.getString(2));
				b.setadd_sheng(rs.getString(3));
				b.setadd_shi(rs.getString(4));
				b.setadd_qu(rs.getString(5));
				b.setaddress(rs.getString(6));
				b.setuser_name(rs.getString(7));
				b.setuser_phone(rs.getString(8));
				resultBeanFreshinfos.add(b);
			
	    	}
	    	pst.execute();
			pst.close();
			rs.close();
	    }catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return resultBeanFreshinfos;
	}

}

