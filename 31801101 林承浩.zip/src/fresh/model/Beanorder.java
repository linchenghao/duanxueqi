package fresh.model;

import java.sql.Date;

public class Beanorder {
	public static Beanorder currentLoginUser=null;
	public static final String[] tblorderTitle={"�������","�û����","����","ԭʼ���","������","�ۿ���","�ʹ�ʱ��","��ַ���","����״̬"};
	public String getCell(int col){
	  if(col==0) return ""+this.getorder_id();
	  else if(col==1) return ""+this.getuser_id();
	  else if(col==2) return ""+this.getcount();
	  else if(col==3) return ""+this.getoriginalm();
	  else if(col==4) return ""+this.getdiscountm();
	  else if(col==5) return ""+this.getdiscount_id();
	  else if(col==6) return ""+this.getarrivaltime();
	  else if(col==7) return ""+this.getaddress_id();
	  else if(col==8) return ""+this.getorder_con();
	  else return "";
	 }
	private Integer order_id;	
	private String user_id;
	private String shangpin_name;
	private Integer count;
	private Double originalm;
	private Double discountm;
	private String discount_id;
	private Date arrivaltime;
	private String address_id;
	private String order_con;
	
	public int getorder_id() {
		return order_id;
	}

	public void setorder_id(int order_id) {
		this.order_id = order_id;
	}
	public String getuser_id() {
		return user_id;
	}

	public void setuser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getshangpin_name() {
		return shangpin_name;
	}
	public void setshangpin_name(String shangpin_name) {
		this.shangpin_name = shangpin_name;
	}
	public int getcount() {
		return count;
	}

	public void setcount(int count) {
		this.count = count;
	}
	public double getoriginalm() {
		return originalm;
	}
	public void setoriginalm(Double originalm) {
		this.originalm = originalm;
	}
	public double getdiscountm() {
		return discountm;
	}

	public void setdiscountm(Double discountm) {
		this.discountm = discountm;
	}
	public String getdiscount_id() {
		return discount_id;
	}

	public void setdiscount_id(String discount_id) {
		this.discount_id = discount_id;
	}
	public Date getarrivaltime() {
		return arrivaltime;
   }
   public void setarrivaltime(Date arrivaltime) {
		this.arrivaltime = arrivaltime;
   }
   public String getaddress_id() {
		return address_id;
	}

   public void setaddress_id(String address_id) {
		this.address_id = address_id;
	}
   public String getorder_con() {
		return order_con;
	}

   public void setorder_con(String order_con) {
		this.order_con = order_con;
	}
	
}
