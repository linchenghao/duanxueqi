package fresh.model;

public class Beanaddress {
	public static Beanaddress currentLoginUser=null;
	private String add_id;
	private String user_id;
	private String add_sheng;
	private String add_shi;
	private String add_qu;
	private String address;
	private String add_name;
	private String add_phone;
	public String getadmin_id(String admin_id) {
		return admin_id;
	}
	public void setadd_id(String add_id) {
		this.add_id = add_id;
	}
	public String getuser_id(String user_id) {
		return user_id;
	}
	public void setuser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getadd_sheng(String add_sheng) {
		return add_sheng;
	}
	public void setadd_sheng(String add_sheng) {
		this.add_sheng = add_sheng;
	}
	public String getadd_shi(String add_shi) {
		return add_shi;
	}
	public void setadd_shi(String add_shi) {
		this.add_shi = add_shi;
	}
	public String getadd_qu(String add_qu) {
		return add_qu;
	}
	public void setadd_qu(String add_qu) {
		this.add_qu = add_qu;
	}
	public String getaddress(String address) {
		return address;
	}
	public void setaddress(String address) {
		this.address = address;
	}
	public String getadd_name(String add_name) {
		return add_name;
	}
	public void setadd_name(String add_name) {
		this.add_name = add_name;
	}
	public String getadd_phone(String add_phone) {
		return add_phone;
	}
	public void setadd_phone(String add_phone) {
		this.add_phone = add_phone;
	}
}
