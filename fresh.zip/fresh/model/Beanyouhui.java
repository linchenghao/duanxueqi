package fresh.model;

public class Beanyouhui {

}
