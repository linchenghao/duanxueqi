package fresh.model;

public class BeanFreshkind {
	private String kind_id;
	private String kind_name;
	private String kind_discribe;
	public static BeanFreshkind currentLoginUser=null;
	public static final String[] tblkindTitle={"������","��������","��������"};
	public String getCell(int col){
	  if(col==0) return this.getKind_id();
	  else if(col==1) return ""+this.getKind_name();
	  else if(col==2) return ""+this.getKind_discribe();
	  else return "";
	 }
	public String getKind_id() {
		return kind_id;
	}

	public void setKind_id(String kind_id) {
		this.kind_id = kind_id;
	}
	public String getKind_name() {
		return kind_name;
	}

	public void setKind_name(String kind_name) {
		this.kind_name = kind_name;
	}
	public String getKind_discribe() {
		return kind_discribe;
	}

	public void setKind_discribe(String kind_discribe) {
		this.kind_discribe = kind_discribe;
	}
}
