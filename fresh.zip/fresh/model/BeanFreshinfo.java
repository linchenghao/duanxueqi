package fresh.model;

public class BeanFreshinfo {
	
}
