package fresh.control;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import fresh.itf.Iadminmanager;
import fresh.model.BeanFreshinfo;
import fresh.model.BeanFreshkind;
import fresh.model.BeanUserinfo;
import fresh.model.Beanaddress;
import fresh.model.Beanadmin;
import fresh.model.Beanadmininfo;
import fresh.util.BaseException;
import fresh.util.BusinessException;
import fresh.util.DBUtil;
import fresh.util.DbException;

public class adminmanager implements Iadminmanager{
	public Beanadmin login(String admin,String pwd) throws BusinessException, DbException
    {
    	Connection conn=null;
	    try {
	    	conn=DBUtil.getConnection();
	    	String sql = "select * from tbl_admin_info where admin_id = ? ";
	    	java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,admin);
	    	java.sql.ResultSet rs=pst.executeQuery();
			if(!rs.next()) throw new BusinessException("��¼�˺Ų�����");
			Beanadmin a=new Beanadmin();
			a.setadmin_id(rs.getString(1));
			a.setadmin_name(rs.getString(2));
			a.setadmin_pwd(rs.getString(3));
			if(!pwd.equals(a.getadmin_pwd()))
				throw new BusinessException("�������");
			pst.close();
			rs.close();
			return a;
	    }catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		// TODO Auto-generated method stub
	    
	}
	
	
	
	public List<Beanadmininfo> loadall() throws BaseException {
		// TODO Auto-generated method stub
		List<Beanadmininfo> resultBeanFreshinfos = new ArrayList<Beanadmininfo>();
    	Connection conn=null;
	    try {
	    	
	    	conn=DBUtil.getConnection();
	    	String sql = "select * from tbl_admin_info";
	    	java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			//pst.setString(1,BeanFreshinfo.currentLoginUser.getShangpin_id());
	    	java.sql.ResultSet rs=pst.executeQuery();

	    	while(rs.next())
	    	{
	    		Beanadmininfo b=new Beanadmininfo();
				b.setadmin_id(rs.getString(1));
				b.setadmin_name(rs.getString(2));
				b.setadmin_pwd(rs.getString(3));
				
				resultBeanFreshinfos.add(b);
			
	    	}
	    	pst.execute();
			pst.close();
			rs.close();
	    }catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return resultBeanFreshinfos;
	}
	public BeanFreshkind addkind(String kind_id, String kind_name, String kind_discribe) throws BaseException{
		if(kind_id.equals(""))
			throw new BusinessException("�����Ų���Ϊ��");
		if(kind_name.equals(""))
			throw new BusinessException("�������Ʋ���Ϊ��");
		if(kind_discribe.equals(""))
			throw new BusinessException("������������Ϊ��");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql = "insert into  tbl_fresh_kind(kind_id,kind_name,kind_discribe) values(?,?,?)";
		    java.sql.PreparedStatement pst=conn.prepareStatement(sql);
		    pst.setString(1, kind_id);
			pst.setString(2, kind_name);
			pst.setString(3, kind_discribe);
			pst.execute();
			pst.close();
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return null;
	}
	public BeanFreshinfo add(String kind_id, String shangpin_id, String shangpin_name, String price, String huiyuan_price, String count, String guige, String specifice) throws BaseException{
		if(kind_id.equals(""))
			throw new BusinessException("�����Ų���Ϊ��");
		if(shangpin_id.equals(""))
			throw new BusinessException("��Ʒ��Ų���Ϊ��");
		if(shangpin_name.equals(""))
			throw new BusinessException("��Ʒ���Ʋ���Ϊ��");
		if(price.equals(""))
			throw new BusinessException("�۸���Ϊ��");
		if(huiyuan_price.equals(""))
			throw new BusinessException("��Ա�۲���Ϊ��");
		if(count.equals(""))
			throw new BusinessException("��������Ϊ��");
		if(guige.equals(""))
			throw new BusinessException("�����Ϊ��");
		if(specifice.equals(""))
			throw new BusinessException("������Ϣ����Ϊ��");
		Connection conn=null;
		try {
			double i=Double.valueOf(price);
			double m=Double.valueOf(huiyuan_price);
			int n=Integer.valueOf(count);
			conn=DBUtil.getConnection();
//			String sql="select * from tbl_fresh_shangpininfo ";
//			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			String sql = "insert into  tbl_fresh_shangpininfo(kind_id, shangpin_id,"
					+ " shangpin_name, price, huiyuan_price, count, guige, specifice) "
					+ "values(?,?,?,?,?,?,?,?)";
		    java.sql.PreparedStatement pst=conn.prepareStatement(sql);
		    pst.setString(1, kind_id);
			pst.setString(2, shangpin_id);
			pst.setString(3, shangpin_name);
			pst.setDouble(4, i);
			pst.setDouble(5, m);
			pst.setInt(6, n);
			pst.setString(7,guige);
			pst.setString(8,specifice);
			pst.execute();
			pst.close();
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return null;
	}
	public BeanFreshinfo del(String shangpin_id)throws BaseException{
		if(shangpin_id.equals(""))
			throw new BusinessException("��Ʒ��Ų���Ϊ��");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="delete from tbl_fresh_shangpininfo where shangpin_id = ?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			
			pst.setString(1, shangpin_id);
			
			pst.execute();
			pst.close();
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return null;
		
	}




}
