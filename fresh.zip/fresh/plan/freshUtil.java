package fresh.plan;
import fresh.control.usermanager;
import fresh.itf.Iusermanager;


public class freshUtil {

	public static Iusermanager usermanager=new usermanager();
	
}
