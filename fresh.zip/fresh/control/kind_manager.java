package fresh.control;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import fresh.itf.Ikind_manager;
import fresh.model.BeanFreshinfo;
import fresh.model.BeanFreshkind;
import fresh.util.BaseException;
import fresh.util.DBUtil;
import fresh.util.DbException;

public class kind_manager implements Ikind_manager {

	@Override
	public List<BeanFreshkind> loadall() throws BaseException {
		// TODO Auto-generated method stub
		List<BeanFreshkind> resultBeanFreshinfos = new ArrayList<BeanFreshkind>();
    	Connection conn=null;
	    try {
	    	
	    	conn=DBUtil.getConnection();
	    	String sql = "select * from tbl_fresh_kind";
	    	java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			//pst.setString(1,BeanFreshinfo.currentLoginUser.getShangpin_id());
	    	java.sql.ResultSet rs=pst.executeQuery();

	    	while(rs.next())
	    	{
	    		BeanFreshkind b=new BeanFreshkind();
				b.setKind_id(rs.getString(1));
				b.setKind_name(rs.getString(2));
				b.setKind_discribe(rs.getString(3));
				
				resultBeanFreshinfos.add(b);
			
	    	}
	    	pst.execute();
			pst.close();
			rs.close();
	    }catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return resultBeanFreshinfos;
	}

}
