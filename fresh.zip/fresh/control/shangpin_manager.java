package fresh.control;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import fresh.itf.Ishangpin_manager;
import fresh.itf.Iusermanager;
import fresh.model.BeanFreshinfo;
import fresh.model.BeanFreshkind;
import fresh.util.BaseException;
import fresh.util.BusinessException;
import fresh.util.DBUtil;
import fresh.util.DbException;

public class shangpin_manager implements Ishangpin_manager{
	@Override
	public List<BeanFreshinfo> loadall(BeanFreshkind p) throws BaseException {
		// TODO Auto-generated method stub
		List<BeanFreshinfo> resultBeanFreshinfos = new ArrayList<BeanFreshinfo>();
    	Connection conn=null;
	    try {
	    	
	    	conn=DBUtil.getConnection();
	    	String sql = "select * from tbl_fresh_shangpininfo  where shangpin_id = ? order by shangpin_id";
	    	java.sql.PreparedStatement pst=conn.prepareStatement(sql);
//			pst.setString(1,p.getKind_id());
	    	java.sql.ResultSet rs=pst.executeQuery();

	    	while(rs.next())
	    	{
				BeanFreshinfo b=new BeanFreshinfo();
				b.setKind_id(rs.getString(1));
				b.setShangpin_id(rs.getString(2));
				b.setShangpin_id(rs.getString(3));
				b.setPrice(rs.getDouble(4));
				b.setHuiyuan_price(rs.getDouble(5));
				b.setCount(rs.getInt(6));
				b.setGuige(rs.getString(7));
				b.setSpecific(rs.getString(8));
				resultBeanFreshinfos.add(b);
			
	    	}
	    	pst.execute();
			pst.close();
			rs.close();
	    }catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return resultBeanFreshinfos;
	}
}
