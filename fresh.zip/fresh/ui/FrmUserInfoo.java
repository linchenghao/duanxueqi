package fresh.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import fresh.model.BeanUserinfo;
import fresh.start.UserUtil;
import fresh.util.BaseException;

import javax.swing.JButton;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

public class FrmUserInfoo extends JFrame implements ActionListener{

	private JPanel contentPane;
	JButton address = new JButton("\u5730\u5740");
	JButton changee = new JButton("\u4FEE\u6539\u5BC6\u7801");
	private Object textField;
	private String n;
	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public FrmUserInfoo() {
		setVisible(true);
		setTitle("\u7528\u6237\u4FE1\u606F");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(52)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
						.addComponent(changee, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(address, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE))
					.addContainerGap(234, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
					.addGap(74)
					.addComponent(address)
					.addGap(28)
					.addComponent(changee)
					.addContainerGap(105, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
		this.address.addActionListener(this);
		this.changee.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == this.changee)
		{
			
			new Frmchangepwd();
			this.setVisible(false);
		}
		else if(e.getSource() == this.address) {
			
			Frmaddress dlg=new Frmaddress();
			dlg.userid = BeanUserinfo.currentLoginUser;
			this.setVisible(false);
		}
		
	}

}
