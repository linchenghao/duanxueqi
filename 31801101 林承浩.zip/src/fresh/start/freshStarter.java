package fresh.start;

import fresh.ui.FrmLogin;


public class freshStarter {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new FrmLogin();
	}

}
