package fresh.control;

public class adminmanager {

}
