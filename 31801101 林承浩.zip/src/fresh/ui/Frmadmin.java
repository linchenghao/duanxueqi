package fresh.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JButton;
import javax.swing.SwingConstants;

public class Frmadmin extends JFrame implements ActionListener{

	private JPanel contentPane;
	JMenu admininfo = new JMenu("\u7BA1\u7406\u5458\u4FE1\u606F");
	JMenu shangpin = new JMenu("\u5546\u54C1\u7BA1\u7406");
	private final JMenuItem addkind = new JMenuItem("\u6DFB\u52A0\u79CD\u7C7B");
	private final JMenuItem find1 = new JMenuItem("\u7BA1\u7406\u5458\u4FE1\u606F");
	private final JMenuItem addshangpin = new JMenuItem("\u6DFB\u52A0\u5546\u54C1");
	private final JMenuItem delshangpin = new JMenuItem("\u5220\u9664\u5546\u54C1");
	private final JButton back = new JButton("\u8FD4\u56DE");
	private final JMenuItem search = new JMenuItem("\u67E5\u8BE2\u5546\u54C1");
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Frmadmin frame = new Frmadmin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Frmadmin() {
		setTitle("\u7BA1\u7406\u5458");
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		
		menuBar.add(admininfo);
		find1.setHorizontalAlignment(SwingConstants.CENTER);
		
		admininfo.add(find1);
		
		menuBar.add(shangpin);
		
		shangpin.add(addkind);
		
		shangpin.add(addshangpin);
		
		shangpin.add(delshangpin);
		
		shangpin.add(search);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		back.setBounds(319, 199, 94, 31);
		
		contentPane.add(back);
		find1.addActionListener(this);
		addkind.addActionListener(this);
		addshangpin.addActionListener(this);
		delshangpin.addActionListener(this);
		back.addActionListener(this);
		search.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == this.find1) {
			Frmadmininfo a = new Frmadmininfo();
			a.setVisible(true);
			
		}
		else if(e.getSource() == this.addkind) {
			new Frmaddkind();
		}
		else if(e.getSource() ==this.addshangpin) {
			new Frmaddshangpin();
		}
		else if(e.getSource() == this.delshangpin) {
			new Frmdelshangpin();
	    }
		else if(e.getSource() == this.search) {
			new Frmadminsearch();
		}
		else if(e.getSource() == this.back) {
			this.setVisible(false);
		}
  }
}
