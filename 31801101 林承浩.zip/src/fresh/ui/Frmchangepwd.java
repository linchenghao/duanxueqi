package fresh.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import fresh.control.usermanager;
import fresh.model.BeanUserinfo;
import fresh.start.UserUtil;
import fresh.util.BaseException;
import javax.swing.BoxLayout;
import javax.swing.SwingConstants;
import java.awt.GridLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;

public  class Frmchangepwd extends JDialog implements ActionListener {
	private final JLabel label = new JLabel("\u65E7\u5BC6\u7801");
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	JButton change = new JButton("\u4FEE\u6539\u5BC6\u7801");
	public Frmchangepwd() {
		setVisible(true);
		setTitle("\u4FEE\u6539\u5BC6\u7801");
		this.setSize(477, 263);
		
		JLabel label_1 = new JLabel("\u65B0\u5BC6\u7801");
		label_1.setBounds(74, 87, 58, 15);
		
		JLabel label_2 = new JLabel("\u786E\u8BA4\u5BC6\u7801");
		label_2.setBounds(74, 126, 58, 15);
		
		textField = new JTextField();
		textField.setBounds(146, 45, 118, 21);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(150, 84, 114, 21);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(150, 123, 114, 21);
		textField_2.setColumns(10);
		change.setBounds(150, 170, 97, 23);
	
		change.addActionListener(this);
		getContentPane().setLayout(null);
		label.setBounds(74, 37, 68, 37);
		getContentPane().add(label);
		getContentPane().add(textField);
		getContentPane().add(label_1);
		getContentPane().add(label_2);
		getContentPane().add(textField_2);
		getContentPane().add(textField_1);
		getContentPane().add(change);
		change.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(e.getSource() ==change){ 
					String oldPwd =textField.getText();
					String newPwd = textField_1.getText();
					String newPwd2 = textField_2.getText();
				    try {
				    	UserUtil.usermanager.changePwd(oldPwd, newPwd, newPwd2);
				    }catch (BaseException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
						return;
					}
//				    setVisible(false);
				}
			}
		});
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	
}
