package fresh.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import fresh.model.BeanUserinfo;
import fresh.model.Beanaddress;
import fresh.start.UserUtil;
import fresh.util.BaseException;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class Frmaddress extends JFrame implements ActionListener{
	public BeanUserinfo userid;
	private JPanel contentPane;
	private JTextField textaddid;
	private JTextField textsheng;
	private JTextField textshi;
	private JTextField textqu;
	private JTextField textaddress;
	private JTextField textusername;
	private JTextField textuserphone;
	private JButton button;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public Frmaddress() {
		setVisible(true);
		
		setTitle("\u5730\u5740\u4FE1\u606F");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel addid = new JLabel("\u5730\u5740\u7F16\u53F7");
		addid.setFont(new Font("����", Font.PLAIN, 14));
		
		JLabel sheng = new JLabel("\u7701");
		sheng.setFont(new Font("����", Font.PLAIN, 14));
		
		JLabel shi = new JLabel("\u5E02");
		shi.setFont(new Font("����", Font.PLAIN, 14));
		
		JLabel qu = new JLabel("\u533A");
		qu.setFont(new Font("����", Font.PLAIN, 14));
		
		JLabel address = new JLabel("\u8BE6\u7EC6\u5730\u5740");
		address.setFont(new Font("����", Font.PLAIN, 14));
		
		JLabel username = new JLabel("\u7528\u6237\u59D3\u540D");
		username.setFont(new Font("����", Font.PLAIN, 14));
		
		JLabel userphone = new JLabel("\u7528\u6237\u624B\u673A\u53F7");
		userphone.setFont(new Font("����", Font.PLAIN, 14));
		
		textaddid = new JTextField();
		textaddid.setColumns(10);
		
		textsheng = new JTextField();
		textsheng.setColumns(10);
		
		textshi = new JTextField();
		textshi.setColumns(10);
		
		textqu = new JTextField();
		textqu.setColumns(10);
		
		textaddress = new JTextField();
		textaddress.setColumns(10);
		
		textusername = new JTextField();
		textusername.setColumns(10);
		
		textuserphone = new JTextField();
		textuserphone.setColumns(10);
		
		button = new JButton("\u786E\u5B9A");
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(userphone, GroupLayout.PREFERRED_SIZE, 74, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(textuserphone, GroupLayout.PREFERRED_SIZE, 114, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(220, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(qu, Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 48, GroupLayout.PREFERRED_SIZE)
						.addComponent(shi, Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
						.addComponent(sheng, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE)
						.addComponent(address, GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE)
						.addComponent(username, GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(textusername, GroupLayout.PREFERRED_SIZE, 114, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(textsheng, GroupLayout.PREFERRED_SIZE, 114, GroupLayout.PREFERRED_SIZE)
							.addGap(65)
							.addComponent(button, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE))
						.addComponent(textshi, GroupLayout.PREFERRED_SIZE, 114, GroupLayout.PREFERRED_SIZE)
						.addComponent(textaddress, GroupLayout.PREFERRED_SIZE, 114, GroupLayout.PREFERRED_SIZE)
						.addComponent(textqu, GroupLayout.PREFERRED_SIZE, 114, GroupLayout.PREFERRED_SIZE))
					.addGap(58))
				.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(addid, GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE)
					.addGap(18)
					.addComponent(textaddid, GroupLayout.PREFERRED_SIZE, 114, GroupLayout.PREFERRED_SIZE)
					.addGap(220))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(43)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(addid)
						.addComponent(textaddid, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(textsheng, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE)
						.addComponent(sheng)
						.addComponent(button))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(shi)
						.addComponent(textshi, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(qu)
						.addComponent(textqu, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(address)
						.addComponent(textaddress, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(username)
						.addComponent(textusername, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(userphone)
						.addComponent(textuserphone, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
					.addContainerGap())
		);
		contentPane.setLayout(gl_contentPane);
		this.button.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == this.button) {
			String addid = this.textaddid.getText();
			String sheng = this.textsheng.getText();
			String shi = this.textshi.getText();
			String qu = this.textqu.getText();
			String address= this.textaddress.getText();
			String username = this.textusername.getText();
			String userphone = this.textuserphone.getText();
			System.out.println(BeanUserinfo.currentLoginUser.getuser_id());
		    try { 
				Beanaddress.currentLoginUser=UserUtil.usermanager.add(addid, BeanUserinfo.currentLoginUser.getuser_id(), sheng, shi, qu, address, username, userphone);
		     
		    }catch (BaseException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
				return;
				}
		    this.setVisible(false);
		}
	}
}
