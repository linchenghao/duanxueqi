package fresh.model;

import java.sql.Date;

public class BeanUserinfo {
	public static BeanUserinfo currentLoginUser=null;
	   private String user_id;
	   private String user_name;
	   private String user_sex;
	   private String user_pwd;
	   private String user_phone;
	   private String user_email;
	   private String user_city;
	   private Date register_time;
	   private String user_huiyuan;
	   private Date end_time;
	   public String getuser_id() {
			return user_id;
	   }
	   public void setuser_id(String user_id) {
			this.user_id = user_id;
	   }
	   public String getuser_name() {
			return user_name;
	   }
	   public void setuser_name(String user_name) {
			this.user_name = user_name;
	   }
	   public String getuser_sex() {
			return user_sex;
	   }
	   public void setuser_sex(String user_sex) {
			this.user_sex = user_sex;
	   }
	   public String getuser_pwd() {
			return user_pwd;
	   }
	   public void setuser_pwd(String user_pwd) {
			this.user_pwd = user_pwd;
	   }
	   public String getuser_phone() {
			return user_phone;
	   }
	   public void setuser_phone(String user_phone) {
			this.user_phone = user_phone;
	   }
	   public String getuser_email() {
			return user_email;
	   }
	   public void setuser_email(String user_email) {
			this.user_email = user_email;
	   }
	   public String getuser_city() {
			return user_city;
	   }
	   public void setuser_city(String user_city) {
			this.user_city = user_city;
	   }
	   public Date getregister_time() {
			return register_time;
	   }
	   public void setregister_time(Date register_time) {
			this.register_time = register_time;
	   }
	   public String getuser_huiyuan() {
			return user_huiyuan;
	   }
	   public void setuser_huiyuan(String user_huiyuan) {
			this.user_huiyuan = user_huiyuan;
	   }
	   public Date getend_time() {
			return end_time;
	   }
	   public void setend_time(Date end_time) {
			this.end_time = end_time;
	   }
}
