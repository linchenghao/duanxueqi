package fresh.model;
import java.sql.Date;
public class Beanadmin {
	public static Beanadmin currentLoginUser=null;
	private String admin_id;
	private String admin_name;
	private String admin_pwd;


	public String getadmin_id() {
		return admin_id;
	}

	public void setadmin_id(String admin_id) {
		this.admin_id = admin_id;
	}
	public String getadmin_name() {
		return admin_name;
	}

	public void setadmin_name(String admin_name) {
		this.admin_name = admin_name;
	}
	public String getadmin_pwd() {
		return admin_pwd;
	}

	public void setadmin_pwd(String admin_pwd) {
		this.admin_pwd = admin_pwd;
	}
}