package fresh.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

/*import sun.tools.tree.ThisExpression;*/
import fresh.util.BaseException;
import fresh.model.BeanUserinfo;
import fresh.start.UserUtil;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Dialog.ModalExclusionType;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class FrmLogin extends JFrame implements ActionListener{
	
	//private JButton btnNewButton = new JButton("\u7528\u6237\u767B\u5F55");
	private JPanel contentPane;
	private JTextField textField= new JTextField(20);
	private JPasswordField passwordField= new JPasswordField(20);
	JButton button1 = new JButton("\u7528\u6237\u767B\u5F55");
   // textField = new JTextField(20);
    //passwordField = new JPasswordField(20);
	/**
	 * Launch the application.
	 */
	/**
	 * Create the frame.
	 * 
	 */
	JButton button = new JButton("\u7BA1\u7406\u5458\u767B\u5F55");
	JButton button2 = new JButton("\u7528\u6237\u6CE8\u518C");
	
	public FrmLogin() {
		setTitle("\u751F\u9C9C\u7CFB\u7EDF");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		button.setBounds(57, 63, 114, 23);
		contentPane.add(button);
		this.button.addActionListener(this);
		button1.setBounds(57, 122, 97, 23);
		contentPane.add(button1);
		button2.setBounds(57, 171, 97, 23);
		contentPane.add(button2);
		this.button2.addActionListener(this);
		this.button1.addActionListener(this);
	}
	
	
	
	@Override
   public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == this.button1)
		{

			new FrmUserlogin();
		}

		
		else if(e.getSource() == this.button2)
		{
			new FrmUserReg();
		}
		else if(e.getSource() == this.button) {
			new Frmadminlogin();
		}

			
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmLogin frame = new FrmLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
