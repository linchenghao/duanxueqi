package fresh.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import fresh.model.BeanFreshinfo;
import fresh.model.BeanFreshkind;
import fresh.model.Beanadmininfo;
import fresh.start.UserUtil;
import fresh.util.BaseException;

import javax.swing.JTable;

public class Frmadmininfo extends JFrame {
	private JPanel contentPane;
	List <Beanadmininfo> alladmin = null;
	 private Object tbladminData[][];
	 DefaultTableModel tabadminModel=new DefaultTableModel();
	 private Object tbladminTitle[]=Beanadmininfo.tbladminTitle;
	 private JTable dataadminPlan=new JTable(tabadminModel);
	 private  void reloadadminTable() {
		  try {
		   alladmin = UserUtil.adminmanager.loadall();
		  }catch (BaseException e) {
		   JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
		   return;
		  }
		  tbladminData =  new Object[alladmin.size()][Beanadmininfo.tbladminTitle.length];
		  //System.out.print(allshangpin.size());
		  for(int i=0;i<alladmin.size();i++){
			  for(int j=0;j<Beanadmininfo.tbladminTitle.length;j++)
				  tbladminData[i][j]=alladmin.get(i).getCell(j);
		  }
		  tabadminModel.setDataVector(tbladminData,tbladminTitle);
		  this.dataadminPlan.validate();
		  this.dataadminPlan.repaint();
		 }
	/**
	 * Launch the application.
	 */


	/**
	 * Create the frame.
	 */
	public Frmadmininfo() {
		this.setTitle("����Ա��Ϣ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
	
		JScrollPane scrollPane1 = new JScrollPane(this.dataadminPlan);
		scrollPane1.setBounds(5, 5, 426, 253);
	       contentPane.setLayout(null);
	       this.getContentPane().add(scrollPane1);
	       this.reloadadminTable();
	}

}
