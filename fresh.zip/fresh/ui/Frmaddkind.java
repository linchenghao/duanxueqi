package fresh.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import fresh.model.BeanFreshinfo;
import fresh.model.BeanFreshkind;
import fresh.start.UserUtil;
import fresh.util.BaseException;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

public class Frmaddkind extends JFrame implements ActionListener{

	private JPanel contentPane;
	private JTextField kindidd;
	private JTextField kindnamee;
	private JTextField kinddiscb;
	private JButton button;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Frmaddkind frame = new Frmaddkind();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Frmaddkind() {
		this.setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel kindid = new JLabel("\u79CD\u7C7B\u7F16\u53F7");
		kindid.setBounds(32, 38, 58, 15);
		contentPane.add(kindid);
		
		JLabel kindname = new JLabel("\u79CD\u7C7B\u540D\u79F0");
		kindname.setBounds(32, 82, 58, 15);
		contentPane.add(kindname);
		
		JLabel label_2 = new JLabel("\u79CD\u7C7B\u63CF\u8FF0");
		label_2.setBounds(32, 119, 58, 15);
		contentPane.add(label_2);
		
		kindidd = new JTextField();
		kindidd.setBounds(100, 38, 102, 21);
		contentPane.add(kindidd);
		kindidd.setColumns(10);
		
		kindnamee = new JTextField();
		kindnamee.setColumns(10);
		kindnamee.setBounds(100, 79, 102, 21);
		contentPane.add(kindnamee);
		
		kinddiscb = new JTextField();
		kinddiscb.setColumns(10);
		kinddiscb.setBounds(100, 116, 102, 21);
		contentPane.add(kinddiscb);
		
		button = new JButton("\u786E\u8BA4\u6DFB\u52A0");
		button.setBounds(32, 187, 97, 23);
		contentPane.add(button);
		button.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == this.button)
		{
			String kind_id = this.kindidd.getText();
		    String kind_name = this.kindnamee.getText();
		    String kind_discribe = this.kinddiscb.getText();
		    
		    try {
		    	BeanFreshkind.currentLoginUser=UserUtil.adminmanager.addkind(kind_id, kind_name, kind_discribe);
		    	 
		    }catch (BaseException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
				return;
				}
		    this.setVisible(false);
		}
	}

}
