package fresh.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;

public class FrmUser extends JFrame implements ActionListener{
	
	private JPanel contentPane;
	JMenuItem personinfo = new JMenuItem("\u4E2A\u4EBA\u4FE1\u606F\u7BA1\u7406");
	JMenuItem addinfo = new JMenuItem("\u5730\u5740\u7BA1\u7406");
	JMenuItem find = new JMenuItem("\u67E5\u8BE2\u5546\u54C1");
	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	
	public FrmUser() {
		setVisible(false);
		setTitle("\u6B22\u8FCE");
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		JMenu mnNewMenu = new JMenu("\u7528\u6237\u7BA1\u7406");
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
	
		menuBar.add(mnNewMenu);
		
		mnNewMenu.add(addinfo);
		
		mnNewMenu.add(personinfo);
		
		JMenu mnNewMenu_1 = new JMenu("\u751F\u9C9C\u4FE1\u606F");
		menuBar.add(mnNewMenu_1);
		
		
		mnNewMenu_1.add(find);
		
		JMenu mnNewMenu_2 = new JMenu("\u7528\u6237\u4FE1\u606F");
		menuBar.add(mnNewMenu_2);
		
		JMenuItem mntmNewMenuItem_3 = new JMenuItem("\u8D2D\u7269\u8F66\u67E5\u8BE2");
		mnNewMenu_2.add(mntmNewMenuItem_3);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		personinfo.addActionListener(this);
		find.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == this.personinfo) {
			new FrmUserInfoo();
//			this.setVisible(false);
		}
		else if(e.getSource() == this.find)
			new Frm_shangpin(this, "", true);
//			(new Frm_shangpin(this, "", true)).setVisible(true);
//			this.setVisible(false);
		}
	}

