package fresh.model;

public class Beanaddress {
	public static Beanaddress currentLoginUser=null;
	public static final String[] tbluseraddTitle={"��ַ���","�û����","ʡ","��","��","��ϸ��ַ","�û�����","�û��ֻ���"};
	private String add_id;
	private String user_id;
	private String add_sheng;
	private String add_shi;
	private String add_qu;
	private String address;
	private String user_phone;
	private String user_name;
	public String getCell(int col){
		  if(col==0) return this.getadd_id();
		  else if(col==1) return ""+this.getuser_id();
		  else if(col==2) return ""+this.getadd_sheng();
		  else if(col==3) return ""+this.getadd_shi();
		  else if(col==4) return ""+this.getadd_qu();
		  else if(col==5) return ""+this.getaddress();
		  else if(col==6) return ""+this.getuser_name();
		  else if(col==7) return ""+this.getuser_phone();
		  else return "";
		 }
	public String getadd_id() {
		return add_id;
	}
	public void setadd_id(String add_id) {
		this.add_id = add_id;
	}
	public String getuser_id() {
		return user_id;
	}
	public void setuser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getadd_sheng() {
		return add_sheng;
	}
	public void setadd_sheng(String add_sheng) {
		this.add_sheng = add_sheng;
	}
	public String getadd_shi() {
		return add_shi;
	}
	public void setadd_shi(String add_shi) {
		this.add_shi = add_shi;
	}
	public String getadd_qu() {
		return add_qu;
	}
	public void setadd_qu(String add_qu) {
		this.add_qu = add_qu;
	}
	public String getaddress() {
		return address;
	}
	public void setaddress(String address) {
		this.address = address;
	}
	public String getuser_name() {
		return user_name;
	}
	public void setuser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getuser_phone() {
		return user_phone;
	}
	public void setuser_phone(String user_phone) {
		this.user_phone = user_phone;
	}
	
}
