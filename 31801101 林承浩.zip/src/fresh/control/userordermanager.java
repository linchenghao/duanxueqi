package fresh.control;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import fresh.itf.Iuserordermanager;
import fresh.model.BeanFreshinfo;
import fresh.model.BeanFreshkind;
import fresh.model.BeanUserinfo;
import fresh.model.Beanaddress;
import fresh.model.Beanorder;
import fresh.util.BaseException;
import fresh.util.BusinessException;
import fresh.util.DBUtil;
import fresh.util.DbException;


public class userordermanager implements Iuserordermanager {

	@Override
	public List<Beanorder> loadall() throws BaseException {
		// TODO Auto-generated method stub
		List<Beanorder> resultBeanFreshinfos = new ArrayList<Beanorder>();
    	Connection conn=null;
	    try {
	    	
	    	conn=DBUtil.getConnection();
	    	String sql = "select * from tbl_user_order";
	    	java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			//pst.setString(1,BeanFreshinfo.currentLoginUser.getShangpin_id());
	    	java.sql.ResultSet rs=pst.executeQuery();

	    	while(rs.next())
	    	{
	    		Beanorder b=new Beanorder();
				b.setorder_id(rs.getInt(1));
				b.setuser_id(rs.getString(2));
				b.setcount(rs.getInt(3));
				b.setoriginalm(rs.getDouble(4));
				b.setdiscountm(rs.getDouble(5));
				b.setdiscount_id(rs.getString(6));
				b.setarrivaltime(rs.getDate(7));
				b.setaddress_id(rs.getString(8));
				b.setorder_con(rs.getString(9));
				resultBeanFreshinfos.add(b);
			
	    	}
	    	pst.execute();
			pst.close();
			rs.close();
	    }catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return resultBeanFreshinfos;
	}
	public Beanorder xiadan(BeanFreshinfo a,int b)throws BaseException
	{
		//System.out.print(a.getCount());
		if(b>a.getCount()) {
			JOptionPane.showMessageDialog(null,"��������", "����",JOptionPane.ERROR_MESSAGE);
				return null;
		}
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			int order_id=1;
			String sql ="select max(order_id) from tbl_user_order";
			java.sql.PreparedStatement pst = conn.prepareStatement(sql);
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				order_id=rs.getInt(1)+1;
			}
			
			 sql = "insert into tbl_user_order(order_id,user_id,count,originalm,discountm,discount_id,arrivaltime,order_con) values(?,?,?,?,?,?,?,?) ";

			pst = conn.prepareStatement(sql);
			pst.setInt(1,order_id);
			pst.setString(2, BeanUserinfo.currentLoginUser.getuser_id());
			pst.setInt(3, b);
			pst.setDouble(4, b*(Double.valueOf(a.getPrice())));			
		    pst.setDouble(5, b*(Double.valueOf(a.getHuiyuan_price())));
			pst.setString(6,"1");
			pst.setTimestamp(7,new java.sql.Timestamp(System.currentTimeMillis() + 3600000L));
			pst.setString(8,"������");
			pst.execute();
			pst.close();
			
			sql = "update tbl_fresh_shangpininfo set count = count - ? where shangpin_id = ?";
			pst = conn.prepareStatement(sql);
			pst.setInt(1, b);
			pst.setString(2, a.getShangpin_id());
			pst.execute();
			pst.close();
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();		
	      }

		}
		return null;
	}
	public Beanorder choose(Beanaddress p)throws BaseException{
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			int order_id=0;
			String sql ="select max(order_id) from tbl_user_order";
			java.sql.PreparedStatement pst = conn.prepareStatement(sql);
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				order_id=rs.getInt(1);
			}
			
			sql = "update tbl_user_order set address_id = ? where order_id =?";
			pst = conn.prepareStatement(sql);
			//pst = conn.prepareStatement(sql);
			pst.setString(1,p.getadd_id());
			pst.setInt(2,order_id);
			pst.execute();
			pst.close();
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();		
	      }

		}
		return null;	
	}
}
