package fresh.model;

public class Beanadmininfo {
	private String admin_id;
	private String admin_name;
	private String admin_pwd;
	public static Beanadmininfo currentLoginUser=null;
	public static final String[] tbladminTitle={"����Ա���","����Ա����","����"};
	public String getCell(int col){
	  if(col==0) return this.getadmin_id();
	  else if(col==1) return ""+this.getadmin_name();
	  else if(col==2) return ""+this.getadmin_pwd();
	  else return "";
	 }
	public String getadmin_id() {
		return admin_id;
	}

	public void setadmin_id(String admin_id) {
		this.admin_id = admin_id;
	}
	public String getadmin_name() {
		return admin_name;
	}

	public void setadmin_name(String admin_name) {
		this.admin_name = admin_name;
	}
	public String getadmin_pwd() {
		return admin_pwd;
	}

	public void setadmin_pwd(String admin_pwd) {
		this.admin_pwd = admin_pwd;
	}
}
