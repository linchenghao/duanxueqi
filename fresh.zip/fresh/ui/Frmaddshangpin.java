package fresh.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import fresh.model.BeanFreshinfo;
import fresh.model.BeanUserinfo;
import fresh.start.UserUtil;
import fresh.util.BaseException;
import java.awt.Font;
import javax.swing.JButton;

public class Frmaddshangpin extends JFrame implements ActionListener{
	private JTextField kind;
	private JTextField shpid;
	private JTextField shpname;
	private JTextField price;
	private JTextField vipp;
	private JTextField count;
	private JTextField guige;
	private JTextField specific;
	JButton button = new JButton("\u786E\u8BA4\u6DFB\u52A0");
	public Frmaddshangpin() {
	setTitle("\u6DFB\u52A0\u5546\u54C1");
	getContentPane().setLayout(null);
	
	JLabel label = new JLabel("\u79CD\u7C7B\u7F16\u53F7");
	label.setBounds(56, 33, 58, 15);
	getContentPane().add(label);
	
	JLabel label_1 = new JLabel("\u5546\u54C1\u7F16\u53F7");
	label_1.setFont(new Font("����", Font.PLAIN, 12));
	label_1.setBounds(56, 71, 58, 15);
	getContentPane().add(label_1);
	
	JLabel label_2 = new JLabel("\u5546\u54C1\u540D\u79F0");
	label_2.setBounds(56, 107, 58, 15);
	getContentPane().add(label_2);
	
	JLabel label_3 = new JLabel("\u4EF7\u683C");
	label_3.setBounds(56, 144, 58, 19);
	getContentPane().add(label_3);
	
	JLabel label_4 = new JLabel("\u4F1A\u5458\u4EF7");
	label_4.setBounds(56, 183, 58, 15);
	getContentPane().add(label_4);
	
	JLabel label_5 = new JLabel("\u6570\u91CF");
	label_5.setBounds(56, 222, 58, 15);
	getContentPane().add(label_5);
	
	JLabel label_6 = new JLabel("\u89C4\u683C");
	label_6.setBounds(56, 263, 58, 15);
	getContentPane().add(label_6);
	
	JLabel label_7 = new JLabel("\u5177\u4F53");
	label_7.setBounds(56, 303, 58, 15);
	getContentPane().add(label_7);
	
	kind = new JTextField();
	kind.setBounds(164, 30, 94, 21);
	getContentPane().add(kind);
	kind.setColumns(10);
	
	shpid = new JTextField();
	shpid.setBounds(164, 68, 94, 21);
	getContentPane().add(shpid);
	shpid.setColumns(10);
	
	shpname = new JTextField();
	shpname.setBounds(164, 104, 94, 21);
	getContentPane().add(shpname);
	shpname.setColumns(10);
	
	price = new JTextField();
	price.setBounds(164, 143, 94, 21);
	getContentPane().add(price);
	price.setColumns(10);
	
	vipp = new JTextField();
	vipp.setBounds(164, 180, 94, 21);
	getContentPane().add(vipp);
	vipp.setColumns(10);
	
	count = new JTextField();
	count.setBounds(164, 219, 94, 21);
	getContentPane().add(count);
	count.setColumns(10);
	
	guige = new JTextField();
	guige.setBounds(164, 260, 94, 21);
	getContentPane().add(guige);
	guige.setColumns(10);
	
	specific = new JTextField();
	specific.setBounds(164, 300, 94, 21);
	getContentPane().add(specific);
	specific.setColumns(10);
	
	
	button.setBounds(56, 359, 97, 23);
	getContentPane().add(button);
	this.setVisible(true);
	this.button.addActionListener(this);
}

@Override
public void actionPerformed(ActionEvent e) {
	// TODO Auto-generated method stub
	if(e.getSource() == this.button)
	{
		String kind = this.kind.getText();
	    String shpid = this.shpid.getText();
	    String shpname = this.shpname.getText();
	    String price = this.price.getText();
	    String vipp = this.vipp.getText();
	    String count = this.count.getText();
	    String guige = this.guige.getText();
	    String specific = this.specific.getText();
	    try {
	    	BeanFreshinfo.currentLoginUser=UserUtil.adminmanager.add(kind, shpid, shpname, price, vipp, count, guige, specific);
	    	 
	    }catch (BaseException e1) {
			JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
			return;
			}
	    this.setVisible(false);
	}
   }
}
