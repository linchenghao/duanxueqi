package fresh.itf;
import java.util.List;

import fresh.model.BeanFreshinfo;
import fresh.model.BeanFreshkind;
import fresh.util.BaseException;
import fresh.util.BusinessException;
import fresh.util.DbException;
public interface Ishangpin_manager {
	public List<BeanFreshinfo> loadall(BeanFreshkind p) throws  BaseException;
}
